package robotService.entities.robot;

public interface Robot {
    String getName();

    void setName(String name);

    int getKilograms();

    double getPrice();

    void eating();
}
