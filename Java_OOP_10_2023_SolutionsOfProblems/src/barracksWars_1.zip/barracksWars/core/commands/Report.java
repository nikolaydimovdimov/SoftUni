package barracksWars.core.commands;

public class Report {
}
