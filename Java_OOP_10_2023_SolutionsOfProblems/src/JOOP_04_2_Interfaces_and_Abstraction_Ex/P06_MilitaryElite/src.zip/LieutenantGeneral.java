import java.util.Collection;

public interface LieutenantGeneral {
    Collection<Private> getPrivs();
    void addPrivate(Private priv);
}
