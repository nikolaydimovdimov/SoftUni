public enum State {
    inProgress,
    finished;
}
