package JOOP_01_2_Working_with_Abstraction_Ex.P04_TrafficLights;

public enum Lights {
    RED,
    GREEN,
    YELLOW


}
