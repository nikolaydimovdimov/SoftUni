package JOOP_01_2_Working_with_Abstraction_Ex;

public enum CardSuits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;

    CardSuits() {
    }

    @Override
    public String toString() {
        return String.format("Ordinal value: %d; Name value: %s",
                this.ordinal(),this.name());
    }
}
