package implementations;

import java.util.Arrays;

public class TheMatrix {
    private char[][] matrix;
    private char fillChar;
    private char toBeReplaced;
    private int startRow;
    private int startCol;

    public TheMatrix(char[][] matrix, char fillChar, int startRow, int startCol) {
        this.matrix = matrix;
        this.fillChar = fillChar;
        this.startRow = startRow;
        this.startCol = startCol;
        this.toBeReplaced = this.matrix[this.startRow][this.startCol];
    }

    public void solve() {
        fillMatrix(this.startRow, this.startCol);
    }

    public void fillMatrix(int row, int col) {
        if (isIndexesOutOfBound(row, col) || this.matrix[row][col] != toBeReplaced) {
            return;
        }
        this.matrix[row][col] = fillChar;
        fillMatrix(row - 1, col);
        fillMatrix(row + 1, col);
        fillMatrix(row, col - 1);
        fillMatrix(row, col + 1);
    }

    private boolean isIndexesOutOfBound(int r, int c) {
        return r < 0 || r >= this.matrix.length || c < 0 || c >= this.matrix[r].length;
    }

    public String toOutputString() {
        StringBuilder output = new StringBuilder();
        for (char[] row : this.matrix) {
            for (char c : row) {
                output.append(c);
            }
            output.append(System.lineSeparator());
        }
        return output.toString().trim();
    }
}
