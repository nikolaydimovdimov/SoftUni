package implementations;

import interfaces.AbstractTree;

import java.util.*;

public class Tree<E> implements AbstractTree<E> {

    private E key;
    private Tree<E> parent;
    private List<Tree<E>> children;


    public Tree(Object key) {
        this.key = (E) key;
        this.setParent(null);
        this.children = new ArrayList<>();
    }

    @Override
    public void setParent(Tree<E> parent) {
        this.parent = parent;
    }

    @Override
    public void addChild(Tree<E> child) {
        this.children.add(child);
    }

    @Override
    public Tree<E> getParent() {
        return this.parent;
    }

    @Override
    public E getKey() {
        return this.key;
    }

    @Override
    public String getAsString() {
        StringBuilder treeString = new StringBuilder();

        traverseTreeRec(treeString, 0, this);

        return treeString.toString().trim();
    }

    private void traverseTreeRec(StringBuilder treeString, int spaces, Tree<E> eTree) {

        treeString.append(makeSpaces(spaces));
        treeString.append(eTree.getKey());
        treeString.append(System.lineSeparator());
        spaces += 2;
        for (Tree<E> child : eTree.children) {
            traverseTreeRec(treeString, spaces, child);
        }
    }

    private StringBuilder makeSpaces(int spaces) {
        StringBuilder spacesString = new StringBuilder();
        for (int i = 0; i < spaces; i++) {
            spacesString.append(" ");
        }
        return spacesString;
    }

    @Override
    public List<E> getLeafKeys() {
        List<E> leafs = new ArrayList<>();
        getLeafsRec(leafs, this);
        return leafs;
    }

    private void getLeafsRec(List<E> leafs, Tree<E> eTree) {
        if (eTree.children.isEmpty()) {
            leafs.add(eTree.getKey());
        }
        for (Tree<E> child : eTree.children) {
            getLeafsRec(leafs, child);
        }
    }

    @Override
    public List<E> getMiddleKeys() {
        List<E> middleKeys = new ArrayList<>();
        getMiddleKeysRec(middleKeys, this);
        return middleKeys;
    }

    private void getMiddleKeysRec(List<E> middleKeys, Tree<E> eTree) {
        if (!eTree.children.isEmpty() && eTree.getParent() != null) {
            middleKeys.add(eTree.getKey());
        }
        for (Tree<E> child : eTree.children) {
            getMiddleKeysRec(middleKeys, child);
        }
    }


    @Override
    public Tree<E> getDeepestLeftmostNode() {
        int level = 0;
        int maxLevel = 0;
        Tree<E> deepestNode = null;
        Map<Tree<E>, Integer> leafNodes = new LinkedHashMap<>();

        getDeepestLeafRec(leafNodes, level, this);
        for (Map.Entry<Tree<E>, Integer> nd : leafNodes.entrySet()) {
            if (nd.getValue() > maxLevel) {
                maxLevel = nd.getValue();
                deepestNode = nd.getKey();
            }
        }
        return deepestNode;
    }

    private void getDeepestLeafRec(Map<Tree<E>, Integer> deepestNodes, int level, Tree<E> eTree) {

        if (eTree.children.isEmpty()) {
            deepestNodes.put(eTree, level);
        }
        level++;
        for (Tree<E> child : eTree.children) {
            getDeepestLeafRec(deepestNodes, level, child);
        }
    }

    @Override
    public List<E> getLongestPath() {
        return null;
    }

    @Override
    public List<List<E>> pathsWithGivenSum(int sum) {
        return null;
    }

    @Override
    public List<Tree<E>> subTreesWithGivenSum(int sum) {
        return null;
    }
}



