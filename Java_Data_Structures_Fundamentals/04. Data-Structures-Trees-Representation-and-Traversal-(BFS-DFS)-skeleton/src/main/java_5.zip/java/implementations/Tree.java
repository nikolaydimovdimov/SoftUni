package implementations;

import interfaces.AbstractTree;

import java.security.Key;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public class Tree<E> implements AbstractTree<E> {
    private E value;
    private Tree<E> parent;
    private List<Tree<E>> children;


    public Tree(E value, Tree<E>... children) {
        this.value = value;
        this.parent = null;
        this.children = new ArrayList<>();
        for (Tree<E> child : children) {
            this.children.add(child);
        }
    }

    @Override
    public List<E> orderBfs() {
        ArrayDeque<Tree<E>> childrenQueue = new ArrayDeque<>();
        childrenQueue.offer(this);

        List<E> resultOfTraversing = new ArrayList<>();
        while (!childrenQueue.isEmpty()) {
            Tree<E> currentTree = childrenQueue.poll();
            for (Tree<E> child : currentTree.children) {
                childrenQueue.offer(child);
            }
            resultOfTraversing.add(currentTree.value);
        }
        return resultOfTraversing;
    }

    @Override
    public List<E> orderDfs() {
        List<E> resultOfTraversing = new ArrayList<>();
        doDfs(this, resultOfTraversing);
        return resultOfTraversing;
    }

    private void doDfs(Tree<E> tree, List<E> result) {
        for (Tree<E> child : tree.children) {
            child.doDfs(child, result);
        }
        result.add(tree.value);
    }

    @Override
    public void addChild(E parentKey, Tree<E> child) {
        this.findNodeBfs(parentKey).children.add(child);
    }

    private Tree<E> findNodeBfs(E key) {
        ArrayDeque<Tree<E>> childrenQueue = new ArrayDeque<>();
        childrenQueue.offer(this);
        Tree<E> currentTree = null;

        while (!childrenQueue.isEmpty()) {
            currentTree = childrenQueue.poll();
            if (currentTree.value.equals(key)) {
                break;
            }
            for (Tree<E> child : currentTree.children) {
                childrenQueue.offer(child);
            }
        }
        return (Tree<E>) currentTree;
    }

    @Override
    public void removeNode(E nodeKey) {
        Tree<E> currentNode = findParentOfNodeBfs(nodeKey);
        if (currentNode == null) {
            this.children=null;
            this.value=null;
            return;
        }
            for (Tree<E> child : currentNode.children) {
                if (child.value.equals(nodeKey)) {
                    currentNode.children.remove(child);
                    break;
                }
            }
    }

    private Tree<E> findParentOfNodeBfs(E key) {
        ArrayDeque<Tree<E>> childrenQueue = new ArrayDeque<>();
        childrenQueue.offer(this);
        Tree<E> parentOfCurrentTree = null;
        Tree<E> currentTree;

        while (!childrenQueue.isEmpty() && parentOfCurrentTree == null) {
            currentTree = childrenQueue.poll();

            for (Tree<E> child : currentTree.children) {
                if (child.value.equals(key)) {
                    parentOfCurrentTree = currentTree;
                    break;
                }
                childrenQueue.offer(child);
            }
        }
        return (Tree<E>) parentOfCurrentTree;
    }

    @Override
    public void swap(E firstKey, E secondKey) {

    }
}



